"""
STATE_DATA_ANALYSIS.py


Analysis of STATE_DATA dataset, created by:
        STATE_DATA_PROCESS.py

"""




##COMMON CODE TO BOTH FUNCTIONS. 


#Read in keys
#Read in desired variables 



#Read in data


#Construct frequency tables

#Years, by state - including missing
#RE, by state - incluing missing

#Construct missingness report
#First, overall missingness, verifying that all desired variables present
