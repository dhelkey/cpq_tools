def random_data(variable_df, n = 100,
                type_col = 'type', var_col 'var_name'):
    """Generates random datasets with the given  
    
    # Type = num - N(0,1)
    #
    #Check if
    """ 